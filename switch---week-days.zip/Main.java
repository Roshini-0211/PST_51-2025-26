/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    int day =2;
	    switch(day){
	        case (1):
	            System.out.println("The Day is  Sunday");
	            break;
	       case (2):
	            System.out.println("The Day is  Monday");
	            break;
	       case (3):
	            System.out.println("The Day is  Tuesday");
	            break;
	            case (4):
	            System.out.println("The Day is  Wednesday ");
	            break;
	            case (5):
	            System.out.println("The Day is  Thursday");
	            break;
	            case (6):
	            System.out.println("The Day is  Friday");
	            break;
	            default:
	            System.out.println("The Day is  Saturday");
	            break;
	    }
	    }
	}

