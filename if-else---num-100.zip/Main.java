/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    int a=101;
	    if (a>100){
		System.out.println("The Number is "+ a +" Greater than 100");
	    }
	    else{
	        System.out.println("The Number is "+a+"Less than 100 ");
	    }
	}
}
