/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
	public static void main(String[] args) {
	    //declare variables
		int a=2,b=4;
		//addition operation
		System.out.println("a+b="+(a+b));
		//subtraction
		System.out.println("a-b="+(a-b));
		//multiplication
		System.out.println("a*b="+(a*b));
		//division
		System.out.println("a/b="+(a/b));
		//modulus
		System.out.println("a%b="+(a%b));
	}
}