/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		System.out.println("the string is ");
	
	    //String str="rose";
	    Scanner sc= new Scanner(System.in);
	    String str = sc.nextLine();
	  String  reverse = "";
	   for ( int i= str.length()-1;i>=0;i--){
	       reverse = reverse + str.charAt(i);
	   }
	   System.out.printf("reverse string as :" + reverse);
	}
}
