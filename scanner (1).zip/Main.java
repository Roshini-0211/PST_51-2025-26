/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner obj= new Scanner(System.in);
	    String a=obj.next();
	    System.out.println("welcome "+a+" to the new learning");
		
	}
}