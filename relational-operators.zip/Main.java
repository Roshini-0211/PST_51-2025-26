/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
	    int a=34,b=54;
	    
	    System.out.println("a is " + a + " b is " +b);
	     System.out.println ("---------------------------------");
	    System.out.println("a and b are equal is "+(a==b));
	   
		System.out.println("a and b are not equal is "+(a!=b));
		System.out.println("a is Greater value  "+(a>b));
		System.out.println("a is less than b "+(a<b));
		System.out.println("a is greaterthan are equal to b "+(a>=b));
		System.out.println("a is lessthan are equal to b "+(a<=b));
	}
}
