/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
	//Scanner sc=new Scanner (System.in );
	//System.out.printf("Enter num check palindrome : ");
	//int num=sc.nextInt();
	int num = 121;
	int original=num;
	int reverse =0;
	while(num !=0){
	    int digit=num%10;
	   reverse=reverse*10+digit;
	    num=num/10;
	}
	    System.out.println(reverse);
	    if (original == reverse){
	        System.out.println(original + " us this plaindrome ");
	    }else{
	        System.out.println(original +" is not a palindrome ");
	    }
	}
}
