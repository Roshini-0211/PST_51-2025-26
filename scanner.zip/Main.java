/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    Scanner input= new Scanner(System.in);
	    System.out.println("Enter the no 1 : ");
	    int num1=input.nextInt();
	    
	    System.out.println("Enter the no 2 : ");
	    int num2=input.nextInt();
	    int product=num1*num2;
	    int Quotient=num1/num2;
	    
	    int sum=num1+num2;
	    System.out.println("sum is  "+sum);
	    System.out.println("product is : "+product);
	    System.out.println("Quotient is  : "+Quotient);
	    input.close();
	    
	    
	}
}
