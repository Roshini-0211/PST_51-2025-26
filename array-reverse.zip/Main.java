/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		System.out.println("Hello World");
	
	    int[] arr={1,2,3,4,5};
	    
	    int left=0;
	    int right=arr.length-1;
	    while(left<right){
	      int  temp=arr[left];
	      arr[left]=arr[right];
	      arr[right]=temp;
	      left++;
	      right--;
	      
	    }
	    
	    for(int i=0;i<arr.length;i++){
	        System.out.print(arr[i]);
	    }
	    	}
}
